﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TestProject
{
    public class Program
    {
        //Holds fall out positions of items
        public static List<Tuple<char, int, int>> Scent = new List<Tuple<char, int, int>>();
        static void Main(string[] args)
        {
            try
            {
                string input; string gridSize;
                List<string> multiLineInput = new List<string>();
                Console.WriteLine("Input: ");

                while (true)
                {
                    input = Console.ReadLine();
                    if (input == null || input == string.Empty) { break; }
                    multiLineInput.Add(input);
                }
                gridSize = multiLineInput.First();

                // grid size input as number Ex: 53 -- use this when coordinates are single digit
                int[] gridCoOrdinates = gridSize.Select(c => int.Parse(c.ToString())).ToArray();
                // grid size input as comma seperated co ordinates Ex: 55,31 -- use this when coordinates are double digit
                //int[] gridCoOrdinates = gridSize.Split(',').Select(c => int.Parse(c.ToString())).ToArray();

                if (gridCoOrdinates.Length > 2 || gridCoOrdinates.Length == 0)
                {
                    Console.WriteLine("Please provide valid grid size.");
                    return;
                }

                int x = gridCoOrdinates[0];
                int y = gridCoOrdinates[1];

                multiLineInput.RemoveAt(0);
                //Program jellyFish = new Program();
                Console.WriteLine("Output: ");

                foreach (var instruction in multiLineInput)
                {
                    var result = TraverseThroughGrid(x, y, instruction);
                    if (result != null)
                    {
                        Console.WriteLine(result.Item1 + "" + result.Item2 + "" + result.Item3);
                    }
                }
                Console.ReadKey();
            }
            catch (Exception e)
            {
                throw;
            }
        }

        /// <summary>
        /// Traverses item in grid with size x, y with given positionInstruction
        /// </summary>
        /// <param name="x">Grid size for x co-ordinate</param>
        /// <param name="y">Grid size for y co-ordinate</param>
        /// <param name="positionInstruction">Current position with direction and traverse route seperate by a black space</param>
        /// <returns>Tuple with final destination co-ordinates and direction</returns>
        private static Tuple<int, int, string> TraverseThroughGrid(int x, int y, string positionInstruction)
        {
            string[] instruction = positionInstruction.Split(null);
            if (instruction.Length > 2 || instruction.Length == 0)
            {
                Console.WriteLine("Please provide valid instruction : " + positionInstruction);
                return null;
            }
            char[] currentPostion = instruction[0].ToCharArray();
            char[] traverseInstructions = instruction[1].ToCharArray();
            int xPosition = Convert.ToInt16(currentPostion[0].ToString());
            int yPosition = Convert.ToInt16(currentPostion[1].ToString());
            char curDirection = currentPostion[2];
            char newDirection = currentPostion[2];

            foreach (var item in traverseInstructions)
            {
                if (item.Equals('R'))
                {
                    newDirection = CalculateDirection(item, curDirection);
                }
                else if (item.Equals('L'))
                {
                    newDirection = CalculateDirection(item, curDirection);
                }
                else if (item.Equals('F'))
                {
                    UpdatePostition(ref xPosition, ref yPosition, newDirection);
                    if (xPosition > x)
                    {
                        Scent.Add(Tuple.Create(newDirection, xPosition - 1, yPosition));
                        return Tuple.Create(xPosition - 1, yPosition, newDirection.ToString() + "LOST");
                    }
                    if (yPosition > y)
                    {
                        Scent.Add(Tuple.Create(newDirection, xPosition, yPosition - 1));
                        return Tuple.Create(xPosition, yPosition - 1, newDirection.ToString() + "LOST");
                    }
                }
                else
                {
                    throw new Exception("Unknown Instruction : " + item);
                }
                curDirection = newDirection;
            }
            return Tuple.Create(xPosition, yPosition, newDirection.ToString());
        }

        /// <summary>
        /// Calucates direction when item moves under given instructed direction
        /// </summary>
        /// <param name="instruction">Instructed movement (L/R)</param>
        /// <param name="currentDirection">Current direction of the item (N/S/E/W)</param>
        /// <returns>Direction octcome when item follows the instruction</returns>
        private static char CalculateDirection(char instruction, char currentDirection)
        {
            if (instruction == 'L')
            {
                switch (currentDirection)
                {
                    case 'N':
                        return 'W';
                    case 'S':
                        return 'E';
                    case 'E':
                        return 'N';
                    case 'W':
                        return 'S';
                }
            }
            else if (instruction == 'R')
            {
                switch (currentDirection)
                {
                    case 'N':
                        return 'E';
                    case 'S':
                        return 'W';
                    case 'E':
                        return 'S';
                    case 'W':
                        return 'N';
                }
            }
            else
            {
                throw new Exception("Unknown Instruction : " + instruction);
            }
            return currentDirection;
        }

        /// <summary>
        /// Updates position of the item in the grid following the direction
        /// </summary>
        /// <param name="x">Item position x co-ordinate by reference</param>
        /// <param name="y">Item position y co-ordinate by reference</param>
        /// <param name="direction">Direction in which item's position must be updated</param>
        private static void UpdatePostition(ref int x, ref int y, char direction)
        {
            var currentXPos = x;
            var currentYPos = y;

            if (Scent.Any(m => m.Item1 == direction && m.Item2 == currentXPos && m.Item3 == currentYPos))
            {
                return;
            }

            switch (direction)
            {
                case 'N':
                    y = y + 1;
                    break;
                case 'S':
                    y = y - 1;
                    break;
                case 'E':
                    x = x + 1;
                    break;
                case 'W':
                    x = x - 1;
                    break;
                default:
                    throw new Exception("Unknown Direction : " + direction);
            }
        }
    }

    // Sample Input :
    //  53
    //  11E RFRFRFRF
    //  32N FRRFLLFFRRLLFFFFFF
    //  03W LLFFFLFLFL

    // Output :
    //  11E
    //  33NLOST
    //  23S
}